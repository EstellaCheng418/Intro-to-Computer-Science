package cheng.CLUSTER;

import cheng.PARTICLE.Alpha;
import cheng.PARTICLE.Beta;
import cheng.PARTICLE.Gamma;
import cheng.PARTICLE.ImperialParticle;

public class Trion extends ImperialCluster {

    public Trion() {
        super("Trion");
        getParticles().get("Alpha").add(new Alpha());
        getParticles().get("Beta").add(new Beta());
        getParticles().get("Gamma").add(new Gamma());
        getParticles().get("Gamma").add(new Gamma());
    }

    @Override
    public void displayCluster() {
    	for (ImperialParticle p : getParticles().get("Alpha")) {
            p.displayParticle();
        }
        for (ImperialParticle p : getParticles().get("Beta")) {
            p.displayParticle();
        }
        for (ImperialParticle p : getParticles().get("Gamma")) {
            p.displayParticle();
        }
    }

    @Override
    public void displayTotalMassPower() {
        double totalMass = 0;
        double totalPower = 0;

        for (ImperialParticle p : getParticles().get("Alpha")) {
            totalMass += p.getMass();
            totalPower += p.getPower();
        }
        for (ImperialParticle p : getParticles().get("Beta")) {
            totalMass += p.getMass();
            totalPower += p.getPower();
        }
        for (ImperialParticle p : getParticles().get("Gamma")) {
            totalMass += p.getMass();
            totalPower += p.getPower();
        }

        System.out.println(getCID() + " Total Mass: " + totalMass);
        System.out.println(getCID() + " Total Power: " + totalPower);
    }
}