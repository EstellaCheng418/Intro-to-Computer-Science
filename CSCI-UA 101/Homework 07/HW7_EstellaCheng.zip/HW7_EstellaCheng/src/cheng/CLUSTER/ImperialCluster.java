package cheng.CLUSTER;

import java.util.ArrayList;
import java.util.TreeMap;

import cheng.PARTICLE.ImperialParticle;

public abstract class ImperialCluster {

    private String cID;
    private String cType;
    private static int clusterCount = 0;

    private TreeMap<String, ArrayList<ImperialParticle>> particles;

    public ImperialCluster(String cType) {
        this.cType = cType;
        clusterCount++;
        this.cID = "C-" + cType + "-" + clusterCount;

        particles = new TreeMap<String, ArrayList<ImperialParticle>>();
        particles.put("Alpha", new ArrayList<ImperialParticle>());
        particles.put("Beta", new ArrayList<ImperialParticle>());
        particles.put("Gamma", new ArrayList<ImperialParticle>());
    }
    
    // Getters
    public String getCID() {
        return cID;
    }

    public String getCType() {
        return cType;
    }

    public static int getClusterCount() {
        return clusterCount;
    }

    public TreeMap<String, ArrayList<ImperialParticle>> getParticles() {
        return particles;
    }
    
    
    // Methods
    // Prints the ID of every particle in the cluster
    public void displayAllParticles() {
        for (ImperialParticle p : particles.get("Alpha")) {
            System.out.println(p.getPID());
        }
        for (ImperialParticle p : particles.get("Beta")) {
            System.out.println(p.getPID());
        }
        for (ImperialParticle p : particles.get("Gamma")) {
            System.out.println(p.getPID());
        }
    }

    public abstract void displayCluster();

    public abstract void displayTotalMassPower();
}