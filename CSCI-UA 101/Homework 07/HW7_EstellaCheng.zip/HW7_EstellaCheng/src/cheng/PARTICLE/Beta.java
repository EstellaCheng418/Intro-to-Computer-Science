package cheng.PARTICLE;

import cheng.ENUMS.ParticleCharge;
import cheng.ENUMS.ParticleSpin;

public class Beta extends ImperialParticle {

    public Beta() {
        super("Beta", "BP", 10 * Math.pow(10, -2),
              ParticleCharge.NEGATIVE, ParticleSpin.RIGHT, 2.5 * Math.pow(10, 6));
    }

    @Override
    public void displayParticle() {
    	System.out.println(getPType() + ": " + getPID());
    }
}