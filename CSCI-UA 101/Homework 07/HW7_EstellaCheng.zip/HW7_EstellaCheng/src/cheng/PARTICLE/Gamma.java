package cheng.PARTICLE;

import cheng.ENUMS.ParticleCharge;
import cheng.ENUMS.ParticleSpin;

public class Gamma extends ImperialParticle {

    public Gamma() {
        super("Gamma", "CP", 15 * Math.pow(10, -2),
              ParticleCharge.POSITIVE, ParticleSpin.RIGHT, 3 * Math.pow(10, 6));
    }

    @Override
    public void displayParticle() {
    	System.out.println(getPType() + ": " + getPID());
    }
}