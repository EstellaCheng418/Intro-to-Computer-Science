package cheng.PARTICLE;

import cheng.ENUMS.ParticleCharge;
import cheng.ENUMS.ParticleSpin;

public abstract class ImperialParticle {

    private String pID;
    private String pType;
    private String symbol;
    private double mass;
    private ParticleCharge charge;
    private ParticleSpin spin;
    private double power;

    private static int pCount = 1;

    public ImperialParticle(String pType, String symbol, double mass,
                            ParticleCharge charge, ParticleSpin spin, double power) {
        this.pType = pType;
        this.symbol = symbol;
        this.mass = mass;
        this.charge = charge;
        this.spin = spin;
        this.power = power;
        this.pID = "P-" + pType + "-" + pCount;
        pCount++;
    }
    
    // Getters
    public String getPID() {
        return pID;
    }

    public String getPType() {
        return pType;
    }

    public String getSymbol() {
        return symbol;
    }

    public double getMass() {
        return mass;
    }

    public ParticleCharge getCharge() {
        return charge;
    }

    public ParticleSpin getSpin() {
        return spin;
    }

    public double getPower() {
        return power;
    }

    public static int getPCount() {
        return pCount;
    }

    @Override
    public String toString() {
        return "ImperialParticle [pID=" + pID
                + ", pType=" + pType
                + ", symbol=" + symbol
                + ", mass=" + mass
                + ", charge=" + charge
                + ", spin=" + spin
                + ", power=" + power + "]";
    }

    public abstract void displayParticle();
}