package cheng.PARTICLE;

import cheng.ENUMS.ParticleCharge;
import cheng.ENUMS.ParticleSpin;

public class Alpha extends ImperialParticle {

    public Alpha() {
        super("Alpha", "AP", 5 * Math.pow(10, -2),
              ParticleCharge.POSITIVE, ParticleSpin.LEFT, 1.5 * Math.pow(10, 6));
    }

    @Override
    public void displayParticle() {
    	System.out.println(getPType() + ": " + getPID());
    }
}