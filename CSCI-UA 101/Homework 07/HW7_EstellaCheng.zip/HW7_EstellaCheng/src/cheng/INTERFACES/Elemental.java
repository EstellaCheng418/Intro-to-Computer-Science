package cheng.INTERFACES;

import java.util.ArrayList;
import java.util.TreeMap;

import cheng.CLUSTER.ImperialCluster;
import cheng.PARTICLE.ImperialParticle;
import cheng.POLYMER.ImperialPolymer;

import cheng.SUBSTRATE.ImperialSubstrate;
import cheng.SUBSTRATE.Substrate_Sigma;
import cheng.SUBSTRATE.Substrate_Tau;
import cheng.SUBSTRATE.Substrate_Zeta;

public interface Elemental {
	
	// Take a list of particles, returns all their IDs as one string e.g. P-Alpha-1 P-Beta-2 P-Gamma-3
    public static String getParticleIDs(ArrayList<ImperialParticle> A) {
        String result = "";

        for (int i = 0; i < A.size(); i++) {
            result += A.get(i).getPID();
            if (i < A.size() - 1) {
                result += " ";
            }
        }

        return result;
    }
    
    // Create many substrates and stores them in a numbered map
    public static TreeMap<Integer, ImperialSubstrate> buildSubstrates(int sigma, int tau, int zeta) {
        TreeMap<Integer, ImperialSubstrate> subs = new TreeMap<Integer, ImperialSubstrate>();
        int buildNumber = 1;

        for (int i = 0; i < sigma; i++) {
            subs.put(buildNumber, new Substrate_Sigma());
            buildNumber++;
        }

        for (int i = 0; i < tau; i++) {
            subs.put(buildNumber, new Substrate_Tau());
            buildNumber++;
        }

        for (int i = 0; i < zeta; i++) {
            subs.put(buildNumber, new Substrate_Zeta());
            buildNumber++;
        }

        return subs;
    }
    
    // Print everything inside a substrate (its polymers and clusters)
    public static void breakDownSubstrate(ImperialSubstrate sub) {
        System.out.println(sub.getSubType());
        System.out.println("**Polymers**");

        for (ImperialPolymer py : sub.getPolymerDeque()) {
            System.out.println(py.getPyID() + " [" + py.getPyType() + "]");

            for (ImperialCluster cl : py.getClusterStack()) {
                System.out.println("        " + cl.getCID());
            }
        }
    }
}