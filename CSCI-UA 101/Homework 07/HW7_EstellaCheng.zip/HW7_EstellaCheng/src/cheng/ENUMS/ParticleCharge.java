package cheng.ENUMS;

public enum ParticleCharge {
    POSITIVE,
    NEGATIVE
}