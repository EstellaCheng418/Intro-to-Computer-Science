package cheng.ENUMS;

public enum ParticleSpin {
    LEFT,
    RIGHT
}