package cheng.POLYMER;

import cheng.CLUSTER.Boson;
import cheng.CLUSTER.Gluon;
import cheng.CLUSTER.Meson;
import cheng.CLUSTER.Trion;

public class PolyGamma extends ImperialPolymer {

    public PolyGamma() {
        super("PolyGamma");

        clusterStack.push(new Meson());
        clusterStack.push(new Boson());
        clusterStack.push(new Gluon());
        clusterStack.push(new Trion());
    }
}