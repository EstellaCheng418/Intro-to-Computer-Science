package cheng.POLYMER;

import java.util.Stack;

import cheng.CLUSTER.ImperialCluster;

public abstract class ImperialPolymer {

    private String pyID;
    private String pyType;
    private static int polymerCount = 0;

    protected Stack<ImperialCluster> clusterStack;

    public ImperialPolymer(String pyType) {
        this.pyType = pyType;
        polymerCount++;
        this.pyID = "PY-" + pyType + "-" + polymerCount;
        this.clusterStack = new Stack<ImperialCluster>();
    }
    
    // Getters
    public String getPyID() {
        return pyID;
    }

    public String getPyType() {
        return pyType;
    }

    public static int getPolymerCount() {
        return polymerCount;
    }

    public Stack<ImperialCluster> getClusterStack() {
        return clusterStack;
    }
    
    
    // Method
    public void showAllClusterID() {
        for (ImperialCluster c : clusterStack) {
            System.out.println(c.getCID());
        }
    }
}