package cheng.MAIN;

import java.util.TreeMap;

import cheng.INTERFACES.Elemental;
import cheng.SUBSTRATE.ImperialSubstrate;

public class Estella {

    public static void main(String[] args) {
        TreeMap<Integer, ImperialSubstrate> subs = Elemental.buildSubstrates(10, 10, 10);
        Elemental.breakDownSubstrate(subs.get(23));
    }
}