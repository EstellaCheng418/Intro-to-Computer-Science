package cheng.SUBSTRATE;

import java.util.ArrayDeque;

import cheng.POLYMER.ImperialPolymer;

public abstract class ImperialSubstrate {

    private String subID;
    private String subType;
    private static int substrateCount = 0;

    protected ArrayDeque<ImperialPolymer> polymerDeque;

    public ImperialSubstrate(String subType) {
        this.subType = subType;
        substrateCount++;
        this.subID = "SUB-" + subType + "-" + substrateCount;
        this.polymerDeque = new ArrayDeque<ImperialPolymer>();
    }
    
    // Getters
    public String getSubID() {
        return subID;
    }

    public String getSubType() {
        return subType;
    }

    public static int getSubstrateCount() {
        return substrateCount;
    }

    public ArrayDeque<ImperialPolymer> getPolymerDeque() {
        return polymerDeque;
    }
    
    
    // Method
    public void showAllPolymerID() {
        for (ImperialPolymer py : polymerDeque) {
            System.out.println(py.getPyID());
        }
    }
}