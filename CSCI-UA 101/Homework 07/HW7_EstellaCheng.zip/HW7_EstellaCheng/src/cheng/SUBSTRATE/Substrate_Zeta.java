package cheng.SUBSTRATE;

import cheng.POLYMER.PolyAlpha;
import cheng.POLYMER.PolyGamma;

public class Substrate_Zeta extends ImperialSubstrate {

    public Substrate_Zeta() {
        super("Substrate_Zeta");

        polymerDeque.addLast(new PolyAlpha());
        polymerDeque.addLast(new PolyGamma());
    }
}