package cheng.SUBSTRATE;

import cheng.POLYMER.PolyAlpha;
import cheng.POLYMER.PolyBeta;

public class Substrate_Sigma extends ImperialSubstrate {

    public Substrate_Sigma() {
        super("Substrate_Sigma");

        polymerDeque.addLast(new PolyAlpha());
        polymerDeque.addLast(new PolyBeta());
    }
}