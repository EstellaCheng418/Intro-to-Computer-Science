package cheng.SUBSTRATE;

import cheng.POLYMER.PolyBeta;
import cheng.POLYMER.PolyGamma;

public class Substrate_Tau extends ImperialSubstrate {

    public Substrate_Tau() {
        super("Substrate_Tau");

        polymerDeque.addLast(new PolyBeta());
        polymerDeque.addLast(new PolyBeta());
        polymerDeque.addLast(new PolyGamma());
    }
}