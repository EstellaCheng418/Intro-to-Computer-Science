package cheng.MAIN;

import cheng.SIMULATION.Sim;

public class Estella {

    public static String[][] bMap1 = Sim.battleMap(4);
    public static String[][] bMap2 = Sim.battleMap(8);

    public static void main(String[] args) {
        System.out.println("***Engagement 1***");
        Sim.AnalyzeFighterEngagement(bMap1);
        System.out.println();
        System.out.println("***Engagement 2***");
        Sim.AnalyzeFighterEngagement(bMap2);
    }
}
