package cheng.SIMULATION;

import java.util.Random;

public class Sim {

    // =========================
    // TASK 1: build the battle map
    // =========================
    public static String[][] battleMap(int size) {

        String[][] map = new String[size][size];

        for (int r = 0; r < size; r++) {
            for (int c = 0; c < size; c++) {
                map[r][c] = "[ ]";
            }
        }

        Random rand = new Random();

        int tfR = rand.nextInt(size); 
        int tfC = rand.nextInt(size);

        int xwR, xwC;
        do {
            xwR = rand.nextInt(size);
            xwC = rand.nextInt(size);
        } while (xwR == tfR && xwC == tfC);

        map[tfR][tfC] = "*TF*";
        map[xwR][xwC] = "*XW*";

        return map;
    }

    // =========================
    // TASK 2
    // =========================
    public static void AnalyzeFighterEngagement(String[][] bMap) {

        printBattleMap(bMap);

        int[] tf = findCoords(bMap, "*TF*");
        int[] xw = findCoords(bMap, "*XW*");

        int tfR = tf[0], tfC = tf[1];
        int xwR = xw[0], xwC = xw[1];

        double range = distance(tfR, tfC, xwR, xwC);

        // One blank line before table
        System.out.println();

        System.out.printf("%-8s %-15s %-7s %-15s %-7s %-7s %-16s %-7s%n",
                "Fighter", "Fighter Coords", "Target", "Target Coords",
                "Range", "Shot", "Accuracy", "Hit-Miss");

        Random rand = new Random();

        fireThreeShots("Tie", tfR, tfC, "X-Wing", xwR, xwC, range, rand);

        System.out.println();

        fireThreeShots("X-Wing", xwR, xwC, "Tie", tfR, tfC, range, rand);
    }

    // =========================
    private static void fireThreeShots(String shooter, int sR, int sC,
                                       String target, int tR, int tC,
                                       double range, Random rand) {

        int poh = getPohPercent(shooter, range);

        for (int shot = 1; shot <= 3; shot++) {

            int accuracy = rand.nextInt(101);
            int hitMiss = (accuracy <= poh) ? 1 : 0;

            System.out.printf("%-10s %-13s %-9s %-13s %-9.2f %-8d %-16d %-7d%n",
                    shooter,
                    formatCoords(sR, sC),
                    target,
                    formatCoords(tR, tC),
                    range,
                    shot,
                    accuracy,
                    hitMiss);
        }
    }
    
    // =========================
    private static int getPohPercent(String fighter, double range) {

        boolean isTie = fighter.equalsIgnoreCase("Tie");

        if (range <= 3.0) {
            return isTie ? 70 : 85;
        } else if (range <= 6.0) {
            return isTie ? 60 : 70;
        } else if (range <= 8.0) {
            return isTie ? 50 : 60;
        } else {
            return isTie ? 45 : 50;
        }
    }
    
    // =========================
    private static double distance(int r1, int c1, int r2, int c2) {
        int dr = r1 - r2;
        int dc = c1 - c2;
        return Math.sqrt(dr * dr + dc * dc);
    }
    
    // =========================
    private static String formatCoords(int r, int c) {
        return "[" + r + "-" + c + "]";
    }
    
    // =========================
    private static int[] findCoords(String[][] map, String symbol) {
        for (int r = 0; r < map.length; r++) {
            for (int c = 0; c < map[r].length; c++) {
                if (map[r][c].equals(symbol)) {
                    return new int[]{r, c};
                }
            }
        }
        return new int[]{-1, -1};
    }

    // =========================
    private static String center(String s, int width) {
        if (s == null) {
        	s = "";
        }
        if (s.length() >= width) {
        	return s;
        }

        int total = width - s.length();

        int left = (total + 1) / 2;
        int right = total - left;

        return " ".repeat(left) + s + " ".repeat(right);
    }

    
    // =========================
    private static void printBattleMap(String[][] map) {
        int size = map.length;

        final int CELL_W = 5;

        // header 
        System.out.print(" ");
        for (int c = 0; c < size; c++) {
            System.out.print(center("" + (char) ('A' + c), CELL_W));
        }
        System.out.println();

        for (int r = 0; r < size; r++) {

            System.out.print((char) ('A' + r) + ""); 

            for (int c = 0; c < size; c++) {
                System.out.print(center(map[r][c], CELL_W));
            }

            System.out.println();

            if (r != size - 1) {
                System.out.println(); // blank line between rows 
            }
        }
    }
}
