package cheng.FIGHTER_OPS;

public class BuildException extends Exception {

    private static final long serialVersionUID = 1L;
    private String fighterID;

    public BuildException(String fighterID) {
        super("Fighter ID Must Have 5 Letters/Digits: " + fighterID + " is INVALID");
        this.fighterID = fighterID;
    }

    public String getFighterID() {
        return fighterID;
    }
    
    public void setFighterID(String fighterID) {
        this.fighterID = fighterID;
    }
}