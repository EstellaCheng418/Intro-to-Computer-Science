package cheng.ENUMS;

public enum FighterRole {
    Interceptor, Bomber, Fighter
}