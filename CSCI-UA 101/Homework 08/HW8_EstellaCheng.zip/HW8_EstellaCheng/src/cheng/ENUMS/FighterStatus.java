package cheng.ENUMS;

public enum FighterStatus {
    Serviceable, Unserviceable
}