package cheng.ENUMS;

public enum FighterEngine {

    AWING("J77", 120),
    BWING("JL4", 100),
    XWING("R200", 115);

    private String engineType;
    private double thrust;

    private FighterEngine(String engineType, double thrust) {
        this.engineType = engineType;
        this.thrust = thrust;
    }
    
    // Getters
    public String getEngineType() {
        return engineType;
    }

    public double getThrust() {
        return thrust;
    }
    // Setters
    public void setEngineType(String engineType) {
        this.engineType = engineType;
    }

    public void setThrust(double thrust) {
        this.thrust = thrust;
    }
}