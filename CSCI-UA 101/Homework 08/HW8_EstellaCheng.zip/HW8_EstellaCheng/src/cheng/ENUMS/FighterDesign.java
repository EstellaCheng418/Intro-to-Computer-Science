package cheng.ENUMS;

public enum FighterDesign {

    AWING("Most often deployed to disrupt enemy formations, chase down TIE Interceptors, or carry out quick strikes against key targets."),
    BWING("Most often used to punch through Imperial capital ship defenses or disable critical systems with ion weaponry before bomber follow-up"),
    XWING("Most often used as a space superiority fighter and as an escort for AWing and BWing attack craft.");

    private String description;

    private FighterDesign(String description) {
        this.description = description;
    }
    
    // Getter
    public String getDescription() {
        return description;
    }
    // Setter
    public void setDescription(String description) {
        this.description = description;
    }
}