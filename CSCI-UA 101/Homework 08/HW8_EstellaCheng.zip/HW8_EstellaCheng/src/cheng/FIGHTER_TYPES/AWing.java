package cheng.FIGHTER_TYPES;

import cheng.ENUMS.FighterDesign;
import cheng.ENUMS.FighterEngine;
import cheng.ENUMS.FighterRole;
import cheng.ENUMS.FighterStatus;
import cheng.FIGHTER_OPS.BuildException;
import cheng.FIGHTERS.FighterPosition;
import cheng.FIGHTERS.FighterSpecs;
import cheng.FIGHTERS.RebelFighter;

public class AWing extends RebelFighter {

    private static final long serialVersionUID = 1L;

    public AWing(String fID, FighterStatus fStatus, FighterPosition fPos) throws BuildException {
        super(fID,
              FighterRole.Interceptor,
              new FighterSpecs(6.9, 4.47, 2.47, 12.0, FighterEngine.AWING),
              FighterDesign.AWING,
              fStatus,
              fPos);
    }
    
    // Method
    @Override
    public int compareTo(RebelFighter o) {
        return this.getfID().compareTo(o.getfID());
    }

    @Override
    public void showFighterDetails() {
        System.out.println("***A-WING***");
        System.out.printf("Fighter ID: %s       Fighter Status: %s    Fighter Role: %s%n",
                getfID(), getfStatus(), getfRole());

        getfSpecs().displayFighterSpecs();
        getfSpecs().displayFighterEngine();
    }
}