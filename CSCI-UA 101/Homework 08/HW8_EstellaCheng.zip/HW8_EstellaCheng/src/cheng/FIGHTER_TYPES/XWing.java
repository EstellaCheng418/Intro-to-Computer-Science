package cheng.FIGHTER_TYPES;

import cheng.ENUMS.FighterDesign;
import cheng.ENUMS.FighterEngine;
import cheng.ENUMS.FighterRole;
import cheng.ENUMS.FighterStatus;
import cheng.FIGHTER_OPS.BuildException;
import cheng.FIGHTERS.FighterPosition;
import cheng.FIGHTERS.FighterSpecs;
import cheng.FIGHTERS.RebelFighter;

public class XWing extends RebelFighter {

    private static final long serialVersionUID = 1L;

    public XWing(String fID, FighterStatus fStatus, FighterPosition fPos) throws BuildException {
        super(fID,
              FighterRole.Fighter,
              new FighterSpecs(12.5, 11.0, 4.4, 10.0, FighterEngine.XWING),
              FighterDesign.XWING,
              fStatus,
              fPos);
    }
    
    // Method
    @Override
    public int compareTo(RebelFighter o) {
        return this.getfID().compareTo(o.getfID());
    }

    @Override
    public void showFighterDetails() {
        System.out.println("***X-WING***");
        System.out.printf("Fighter ID: %s       Fighter Status: %s    Fighter Role: %s%n",
                getfID(), getfStatus(), getfRole());

        getfSpecs().displayFighterSpecs();
        getfSpecs().displayFighterEngine();
    }
}