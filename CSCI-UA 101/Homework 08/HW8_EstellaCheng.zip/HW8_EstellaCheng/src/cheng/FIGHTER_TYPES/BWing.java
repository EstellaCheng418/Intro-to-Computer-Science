package cheng.FIGHTER_TYPES;

import cheng.ENUMS.FighterDesign;
import cheng.ENUMS.FighterEngine;
import cheng.ENUMS.FighterRole;
import cheng.ENUMS.FighterStatus;
import cheng.FIGHTER_OPS.BuildException;
import cheng.FIGHTERS.FighterPosition;
import cheng.FIGHTERS.FighterSpecs;
import cheng.FIGHTERS.RebelFighter;

public class BWing extends RebelFighter {

    private static final long serialVersionUID = 1L;

    public BWing(String fID, FighterStatus fStatus, FighterPosition fPos) throws BuildException {
        super(fID,
              FighterRole.Bomber,
              new FighterSpecs(16.24, 8.54, 2.44, 19.0, FighterEngine.BWING),
              FighterDesign.BWING,
              fStatus,
              fPos);
    }
    
    // Method
    @Override
    public int compareTo(RebelFighter o) {
        return this.getfID().compareTo(o.getfID());
    }

    @Override
    public void showFighterDetails() {
        System.out.println("***B-WING***");
        System.out.printf("Fighter ID: %s       Fighter Status: %s    Fighter Role: %s%n",
                getfID(), getfStatus(), getfRole());

        getfSpecs().displayFighterSpecs();
        getfSpecs().displayFighterEngine();
    }
}