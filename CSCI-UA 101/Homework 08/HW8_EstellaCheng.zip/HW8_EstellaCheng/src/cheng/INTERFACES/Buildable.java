package cheng.INTERFACES;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.TreeMap;

import cheng.ENUMS.FighterStatus;
import cheng.FIGHTER_OPS.BuildException;
import cheng.FIGHTER_TYPES.AWing;
import cheng.FIGHTER_TYPES.BWing;
import cheng.FIGHTER_TYPES.XWing;
import cheng.FIGHTERS.FighterPosition;
import cheng.FIGHTERS.RebelFighter;

public interface Buildable {

    static String dirData = "src/cheng/DATA/";
    static String dirStore = "src/cheng/STORE_FIGHTER/";
    static TreeMap<String, RebelFighter> rebelFighters = new TreeMap<String, RebelFighter>();
    
    // Method
    abstract void showFighterDetails();

    static void buildFighters(String filename) throws IOException, BuildException {
        BufferedReader br = new BufferedReader(new FileReader(dirData + filename)); // open Fighters file 
        String line;

        while ((line = br.readLine()) != null) {									// read line by line
            if (line.trim().isEmpty()) {
                continue;
            }

            String[] parts = line.trim().split("\\s+");		// split the line
            
            // Extract data
            String fID = parts[0];			
            String type = parts[1];
            FighterStatus status = FighterStatus.valueOf(parts[2]);
            int x = Integer.parseInt(parts[3]);
            int y = Integer.parseInt(parts[4]);
            
            // Create position object + fighter object
            FighterPosition pos = new FighterPosition(x, y);
            RebelFighter rf = null;

            if (type.equals("A-Wing")) {
                rf = new AWing(fID, status, pos);
            } else if (type.equals("B-Wing")) {
                rf = new BWing(fID, status, pos);
            } else if (type.equals("X-Wing")) {
                rf = new XWing(fID, status, pos);
            }
            
            // store in treemap
            if (rf != null) {
                rebelFighters.put(fID, rf);
            }
        }

        br.close();
    }
    
    // Find a fighter by ID → print its details
    static void displaySpecifiedFighter(String fID) {
        RebelFighter rf = rebelFighters.get(fID);
        if (rf != null) {
            rf.showFighterDetails();
        }
    }
    
    // Find a fighter → save it into a file → print confirmation
    static void storeSpecifiedFighter(String fighterID, String filename) throws IOException {
        RebelFighter rf = rebelFighters.get(fighterID);		// Find the fighter

        if (rf != null) {
            File dir = new File(dirStore);					// Make sure folder exists
            if (!dir.exists()) {
                dir.mkdirs();
            }

            ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(dirStore + filename));
            oos.writeObject(rf);
            oos.close();

            System.out.println(fighterID + " has been stored");
        }
    }
}