package cheng.MAIN;

import java.io.IOException;

import cheng.ENUMS.FighterStatus;
import cheng.FIGHTER_OPS.BuildException;
import cheng.FIGHTER_TYPES.AWing;
import cheng.FIGHTERS.FighterPosition;
import cheng.INTERFACES.Buildable;

public class Estella {

    public static void main(String[] args) throws IOException, BuildException {

        Buildable.buildFighters("Fighters");
        Buildable.displaySpecifiedFighter("GAB17");
        Buildable.storeSpecifiedFighter("IIA15", "FighterBay");
        Buildable.rebelFighters.get("AIB06").getfPos().displayLocation();
        System.out.println(Buildable.rebelFighters.get("CCC73").getfDesign().getDescription());

        AWing A = new AWing("ABC1", FighterStatus.Unserviceable, new FighterPosition(0, 0));
    }
}