package cheng.FIGHTERS;

import java.io.Serializable;
import java.util.TreeMap;

import cheng.ENUMS.FighterEngine;

public class FighterSpecs implements Serializable {

    private static final long serialVersionUID = 1L;

    private TreeMap<String, Double> dimensions;
    private FighterEngine engine;

    public FighterSpecs(double length, double width, double height, double mass, FighterEngine engine) {
        this.dimensions = new TreeMap<String, Double>();
        this.dimensions.put("Length", length);
        this.dimensions.put("Width", width);
        this.dimensions.put("Height", height);
        this.dimensions.put("Mass", mass);
        this.engine = engine;
    }
    
    // Getters
    public TreeMap<String, Double> getDimensions() {
        return dimensions;
    }

    public FighterEngine getEngine() {
        return engine;
    }
    
    // Setters
    public void setDimensions(TreeMap<String, Double> dimensions) {
        this.dimensions = dimensions;
    }

    public void setEngine(FighterEngine engine) {
        this.engine = engine;
    }
    
    // Method
    public void displayFighterSpecs() {
        System.out.printf("	Length: %.1f    Width: %.1f     Height: %.1f      Mass: %.1f%n",
                dimensions.get("Length"),
                dimensions.get("Width"),
                dimensions.get("Height"),
                dimensions.get("Mass"));
    }

    public void displayFighterEngine() {
        double mass = dimensions.get("Mass");
        double ratio = engine.getThrust() / mass;
        System.out.printf(
        	    "	Engine Type: %-8s   Engine Thrust: %-8.1f  Thrust-Mass Ratio: %-8.2f%n",
        	    engine.getEngineType(), engine.getThrust(), ratio
        	);
    }

    
}