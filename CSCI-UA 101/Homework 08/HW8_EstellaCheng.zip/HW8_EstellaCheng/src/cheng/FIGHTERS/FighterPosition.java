package cheng.FIGHTERS;

import java.io.Serializable;

public class FighterPosition implements Serializable {

    private static final long serialVersionUID = 1L;

    private int x;
    private int y;

    public FighterPosition(int x, int y) {
        this.x = x;
        this.y = y;
    }
    
    // Getters
    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }
    
    // Setters
    public void setX(int x) {
        this.x = x;
    }

    public void setY(int y) {
        this.y = y;
    }
    
    // Method
    public void displayLocation() {
        System.out.println("Location: " + x + " " + y);
    }

    public double distanceTo(FighterPosition pos) {
        int dx = this.x - pos.x;
        int dy = this.y - pos.y;
        return Math.sqrt(dx * dx + dy * dy);
    }
    
}