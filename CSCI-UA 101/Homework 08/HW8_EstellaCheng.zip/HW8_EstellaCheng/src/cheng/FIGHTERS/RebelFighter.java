package cheng.FIGHTERS;

import java.io.Serializable;

import cheng.ENUMS.FighterDesign;
import cheng.ENUMS.FighterRole;
import cheng.ENUMS.FighterStatus;
import cheng.FIGHTER_OPS.BuildException;
import cheng.INTERFACES.Buildable;

public abstract class RebelFighter implements Comparable<RebelFighter>, Serializable, Buildable {

    private static final long serialVersionUID = 1L;

    private String fID;
    private FighterRole fRole;
    private FighterSpecs fSpecs;
    private FighterDesign fDesign;
    private FighterStatus fStatus;
    private FighterPosition fPos;

    public RebelFighter(String fID, FighterRole fRole, FighterSpecs fSpecs,
                        FighterDesign fDesign, FighterStatus fStatus,
                        FighterPosition fPos) throws BuildException {

        if (fID == null || fID.length() < 5) {
            throw new BuildException(fID);
        }

        this.fID = fID;
        this.fRole = fRole;
        this.fSpecs = fSpecs;
        this.fDesign = fDesign;
        this.fStatus = fStatus;
        this.fPos = fPos;
    }
    
    // Method
    public void displayFighter() {
        System.out.println(fID + " " + fRole + " " + fStatus);
    }
    
    // Getters and Setters
    public String getfID() {
        return fID;
    }

    public FighterRole getfRole() {
        return fRole;
    }

    public FighterSpecs getfSpecs() {
        return fSpecs;
    }

    public FighterDesign getfDesign() {
        return fDesign;
    }

    public FighterStatus getfStatus() {
        return fStatus;
    }

    public FighterPosition getfPos() {
        return fPos;
    }

    public void setfID(String fID) {
        this.fID = fID;
    }

    public void setfRole(FighterRole fRole) {
        this.fRole = fRole;
    }

    public void setfSpecs(FighterSpecs fSpecs) {
        this.fSpecs = fSpecs;
    }

    public void setfDesign(FighterDesign fDesign) {
        this.fDesign = fDesign;
    }

    public void setfStatus(FighterStatus fStatus) {
        this.fStatus = fStatus;
    }

    public void setfPos(FighterPosition fPos) {
        this.fPos = fPos;
    }
}