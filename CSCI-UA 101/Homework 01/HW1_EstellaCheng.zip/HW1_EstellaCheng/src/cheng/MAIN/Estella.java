package cheng.MAIN;

import java.util.Random;

public class Estella {

    public static final int TROOPER_X = 25;
    public static final int TROOPER_Y = 0;
    
    // Max range must be a static variable
    public static double MAX_RANGE = 30.0;

    public static void main(String[] args) {

        Random rand = new Random();

        int totalTargets = 10;
        int engaged = 0;
        int hits = 0;
        int misses = 0;
        int outOfRange = 0;

        double totalDistance = 0.0;
        double accuracy = 70.0;

        // ---------- HEADER LINE ----------
        String header = String.format(
                "%-7s %-6s %-6s %-15s %-15s %-16s %-15s %-13s",
                "Target", "Tgt X", "Tgt Y", "Tgt Distance",
                "Tgt Range", "Tgt Quadrant", "Hit-Miss", "Trpr Accuracy"
        );

        int tableWidth = header.length();

        // ---------- TITLE ----------
        String title = "Stormtrooper Marksmanship Results";
        int tgtRangeIndex = header.indexOf("Tgt Range"); // index where the T begins

        System.out.println(" ".repeat(tgtRangeIndex) + title);

        // ---------- PRINT HEADER + STARS ----------
        System.out.println(header);
        System.out.println("*".repeat(tableWidth));

        // ---------- MAIN LOOP ----------
        for (int t = 1; t <= totalTargets; t++) {

            // Target location (no target zone is y=0..4)
            int x = rand.nextInt(51);      // 0..50
            int y = rand.nextInt(36) + 5;  // 5..40

            // Distance
            double dx = x - TROOPER_X;
            double dy = y - TROOPER_Y;
            double dist = Math.sqrt(dx * dx + dy * dy);
            totalDistance += dist;

            // Range category
            String range;
            boolean inRange = (dist <= MAX_RANGE);

            if (dist <= 10.0) range = "Short";
            else if (dist <= 20.0) range = "Medium";
            else if (dist <= 30.0) range = "Long";
            else range = "*OUT*";

            // Quadrant (x=25 treated as East, y=20 treated as South)
            String quad;
            if (y > 20) {
                quad = (x < 25) ? "NW" : "NE";
            } else {
                quad = (x < 25) ? "SW" : "SE";
            }

            // Hit/Miss logic
            String result;
            double accuracyUsed = accuracy; // accuracy used for THIS target

            if (!inRange) {
                outOfRange++;
                result = "No Shot";
                // no shot, accuracy unchanged
            } else {
                engaged++;
                
                double roll = rand.nextDouble() * 100.0; // 0.0 <= roll < 100.0

                if (roll < accuracy) {
                    hits++;
                    result = "Hit";
                } else {
                    misses++;
                    result = "Miss";
                    accuracy -= 5.0; // decrease for NEXT shot after a miss
                    if (accuracy < 0.0) {
                    	accuracy = 0.0;
                    }
                }
            }
            
            // Put "m" into the distance string
            String distStr = String.format("%.2fm", dist);

            // ---------- PRINT ONE ROW ----------
            System.out.printf(
                    "%-7d %-6d %-6d %-15s %-15s %-16s %-15s %-13.1f%n",
                    t, x, y, distStr, range, quad, result, accuracyUsed
            );
        }

        // ---------- FOOTER STARS ----------
        System.out.println("*".repeat(tableWidth));

        // ---------- SUMMARY ----------
        double overallAccuracy = (engaged == 0) ? 0.0 : ((double) hits / engaged) * 100.0;
        double avgDistance = totalDistance / totalTargets;

        System.out.println();
        System.out.printf("Stormtrooper Engaged: %d targets%n", engaged);
        System.out.printf("        Targets Hit: %d  Targets Missed: %d%n", hits, misses);
        System.out.printf("        Targets Out of Range: %d%n", outOfRange);
        System.out.printf("Trooper Overall Accuracy: %d hits / %d shots...%.2f%%%n",
                hits, engaged, overallAccuracy);
        System.out.printf("Average Target Distance Was: %.2f meters%n", avgDistance);
    }
}
