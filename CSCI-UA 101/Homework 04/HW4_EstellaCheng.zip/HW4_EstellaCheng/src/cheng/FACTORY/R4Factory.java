package cheng.FACTORY;

import cheng.DROIDS.AstromechDroid;
import cheng.DROIDS.R4;

public class R4Factory extends DroidFactory {

    public R4Factory(String factoryID) {
        super(factoryID);
    }

    @Override
    public boolean buildDroids(int count) {

        for (int i = 0; i < count; i++) {
            AstromechDroid droid = new R4();
            getDroidStorage().add(droid);
        }

        return true;
    }

    @Override
    public void displayDroids() {

        for (AstromechDroid droid : getDroidStorage()) {
            droid.displayDroid();
        }
    }
}