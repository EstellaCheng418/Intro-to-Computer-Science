package cheng.FACTORY;

import cheng.DROIDS.AstromechDroid;
import cheng.DROIDS.R3;

public class R3Factory extends DroidFactory {

    public R3Factory(String factoryID) {
        super(factoryID);
    }

    @Override
    public boolean buildDroids(int count) {

        for (int i = 0; i < count; i++) {
            AstromechDroid droid = new R3();
            getDroidStorage().add(droid);
        }

        return true;
    }

    @Override
    public void displayDroids() {

        for (AstromechDroid droid : getDroidStorage()) {
            droid.displayDroid();
        }
    }
}