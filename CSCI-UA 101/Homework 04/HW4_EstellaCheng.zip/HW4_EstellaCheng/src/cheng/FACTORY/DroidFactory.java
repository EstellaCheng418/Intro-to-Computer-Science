package cheng.FACTORY;

import java.util.ArrayList;

import cheng.DROIDS.AstromechDroid;

public abstract class DroidFactory {

    private String factoryID;
    private ArrayList<AstromechDroid> droidStorage;

    public DroidFactory(String factoryID) {
        this.factoryID = factoryID;
        this.droidStorage = new ArrayList<AstromechDroid>();
    }

    public abstract boolean buildDroids(int count);

    public abstract void displayDroids();

    public String getFactoryID() {
        return factoryID;
    }

    public ArrayList<AstromechDroid> getDroidStorage() {
        return droidStorage;
    }
}