package cheng.ARMS;

import cheng.ENUMS.FootPad;
import cheng.ENUMS.Limb;
import cheng.ENUMS.Side;
import cheng.ENUMS.Status;

public class LeftArm extends Arm {

    public LeftArm() {
        super("LA-01");

        setStatus(Status.ONLINE);
        setSide(Side.LEFT);
        setUpper(Limb.Upper);
        setLower(Limb.Lower);
        setPad(FootPad.LEFT_FOOT);
    }

    @Override
    public boolean armCheck() {
        return getStatus() == Status.ONLINE;
    }
}