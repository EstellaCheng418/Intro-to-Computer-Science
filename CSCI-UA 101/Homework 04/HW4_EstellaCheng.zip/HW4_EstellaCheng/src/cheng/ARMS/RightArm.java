package cheng.ARMS;

import cheng.ENUMS.FootPad;
import cheng.ENUMS.Limb;
import cheng.ENUMS.Side;
import cheng.ENUMS.Status;

public class RightArm extends Arm {

    public RightArm() {
        super("RA-02");

        setStatus(Status.ONLINE);
        setSide(Side.RIGHT);
        setUpper(Limb.Upper);
        setLower(Limb.Lower);
        setPad(FootPad.RIGHT_FOOT);
    }

    @Override
    public boolean armCheck() {
        return getStatus() == Status.ONLINE;
    }
}