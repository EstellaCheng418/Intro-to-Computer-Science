package cheng.ARMS;

import cheng.ENUMS.FootPad;
import cheng.ENUMS.Limb;
import cheng.ENUMS.Side;
import cheng.ENUMS.Status;

public abstract class Arm {

    private String serialNumber;
    private Side side;
    private Status status;
    private Limb upper;
    private Limb lower;
    private FootPad pad;

    // Constructor
    public Arm(String serialNumber) {
        this.serialNumber = serialNumber;
    }

    // Abstract method
    public abstract boolean armCheck();

    // Getters
    public String getSerialNumber() {
        return serialNumber;
    }

    public Side getSide() {
        return side;
    }

    public Status getStatus() {
        return status;
    }

    public Limb getUpper() {
        return upper;
    }

    public Limb getLower() {
        return lower;
    }

    public FootPad getPad() {
        return pad;
    }

    // Setters 
    public void setSide(Side side) {
        this.side = side;
    }

    public void setStatus(Status status) {
        this.status = status;
    }

    public void setUpper(Limb upper) {
        this.upper = upper;
    }

    public void setLower(Limb lower) {
        this.lower = lower;
    }

    public void setPad(FootPad pad) {
        this.pad = pad;
    }
}