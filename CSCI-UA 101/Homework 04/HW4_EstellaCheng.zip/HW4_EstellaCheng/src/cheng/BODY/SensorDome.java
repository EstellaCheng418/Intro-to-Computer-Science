package cheng.BODY;

import cheng.ENUMS.Status;

public class SensorDome {

    private String serialNumber;
    private double height;
    private double weight;
    private Status status;

    public SensorDome(String serialNumber) {
        this.serialNumber = "SD-" + serialNumber;
        this.status = Status.ONLINE;

        if (serialNumber.startsWith("R3")) {
            this.height = 2.0;
            this.weight = 200.0;
        } else {
            this.height = 2.0;
            this.weight = 150.0;
        }
    }

    public boolean sensorDomeCheck() {
        return status == Status.ONLINE;
    }

    public String getSerialNumber() {
        return serialNumber;
    }

    public double getHeight() {
        return height;
    }

    public double getWeight() {
        return weight;
    }

    public Status getStatus() {
        return status;
    }
}