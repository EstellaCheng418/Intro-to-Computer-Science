package cheng.BODY;

import cheng.ENUMS.Status;

public class Chasis {

    private String serialNumber;
    private double height;
    private double weight;
    private Status status;

    public Chasis(String serialNumber) {
        this.serialNumber = "CH-" + serialNumber;
        this.status = Status.ONLINE;

        if (serialNumber.startsWith("R3")) {
            this.height = 4.0;
            this.weight = 400.0;
        } else {
            this.height = 5.0;
            this.weight = 500.0;
        }
    }

    public boolean chasisCheck() {
        return status == Status.ONLINE;
    }

    public String getSerialNumber() {
        return serialNumber;
    }

    public double getHeight() {
        return height;
    }

    public double getWeight() {
        return weight;
    }

    public Status getStatus() {
        return status;
    }
}