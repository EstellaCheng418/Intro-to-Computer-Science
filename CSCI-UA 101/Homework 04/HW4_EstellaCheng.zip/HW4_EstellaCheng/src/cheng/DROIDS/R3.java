package cheng.DROIDS;

import cheng.ARMS.LeftArm;
import cheng.ARMS.RightArm;
import cheng.BODY.Chasis;
import cheng.BODY.SensorDome;
import cheng.ENUMS.Battery;
import cheng.ENUMS.Status;
import cheng.INTERFACES.Droidable;

public class R3 extends AstromechDroid {

    private Status R3Status;
    private Battery R3Battery;

    public R3() {
        super(Droidable.generateR3SerialNumber());

        SensorDome dome = new SensorDome(getSerialNumber());
        Chasis chasis = new Chasis(getSerialNumber());
        LeftArm leftArm = new LeftArm();
        RightArm rightArm = new RightArm();

        setDome(dome);
        setChasis(chasis);
        setLeftArm(leftArm);
        setRightArm(rightArm);

        setHeight(dome.getHeight() + chasis.getHeight());
        setWeight(dome.getWeight() + chasis.getWeight());

        this.R3Status = Status.ONLINE;
        this.R3Battery = Battery.R3;
    }

    @Override
    public void displayDroid() {

        System.out.println("R3 Droid	Height: " + getHeight() + "	Weight: " + getWeight());
        System.out.println("Serial Number: " + getSerialNumber());

        System.out.println("Dome Serial Number:	    " + getDome().getSerialNumber() + "   " + getDome().getStatus());
        System.out.println("Chasis Serial Number:	    " + getChasis().getSerialNumber() + "   " + getChasis().getStatus());
        System.out.println("Left Arm Serial Number:	        " + getLeftArm().getSerialNumber() + "   " + getLeftArm().getStatus());
        System.out.println("Right Arm Serial Number:	" + getRightArm().getSerialNumber() + "   " + getRightArm().getStatus());

        System.out.println("Battery: " + R3Battery);
        System.out.println("Status: " + R3Status);
        System.out.println();
    }

    @Override
    public void checkStatus() {
        if (R3Status == Status.ONLINE) {
            System.out.println("R3 Droid is ONLINE");
        } else {
            System.out.println("R3 Droid is OFFLINE");
        }
    }
}