package cheng.DROIDS;

import cheng.ARMS.LeftArm;
import cheng.ARMS.RightArm;
import cheng.BODY.Chasis;
import cheng.BODY.SensorDome;
import cheng.ENUMS.Battery;
import cheng.ENUMS.Radar;
import cheng.ENUMS.Status;
import cheng.INTERFACES.Droidable;

public class R4 extends AstromechDroid {

    private Status R4Status;
    private Battery R4Battery;
    private Radar R4Radar;

    public R4() {
        super(Droidable.generateR4SerialNumber());

        SensorDome dome = new SensorDome(getSerialNumber());
        Chasis chasis = new Chasis(getSerialNumber());
        LeftArm leftArm = new LeftArm();
        RightArm rightArm = new RightArm();

        setDome(dome);
        setChasis(chasis);
        setLeftArm(leftArm);
        setRightArm(rightArm);

        setHeight(dome.getHeight() + chasis.getHeight());
        setWeight(dome.getWeight() + chasis.getWeight());

        this.R4Status = Status.ONLINE;
        this.R4Battery = Battery.R4;
        this.R4Radar = Radar.R4R;
    }

    @Override
    public void displayDroid() {

        System.out.println("R4 Droid	Height: " + getHeight() + "	Weight: " + getWeight());
        System.out.println("Serial Number: " + getSerialNumber());

        System.out.println("Dome Serial Number:	    " + getDome().getSerialNumber() + "  " + getDome().getStatus());
        System.out.println("Chasis Serial Number:	    " + getChasis().getSerialNumber() + "  " + getChasis().getStatus());
        System.out.println("Left Arm Serial Number:	         " + getLeftArm().getSerialNumber() + "  " + getLeftArm().getStatus());
        System.out.println("Right Arm Serial Number:	 " + getRightArm().getSerialNumber() + "  " + getRightArm().getStatus());

        System.out.println("Battery: " + R4Battery);
        System.out.println("Status: " + R4Status);
        System.out.println("Radar: " + R4Radar);
        System.out.println();
    }


    @Override
    public void checkStatus() {
        if (R4Status == Status.ONLINE) {
            System.out.println("R4 Droid is ONLINE");
        } else {
            System.out.println("R4 Droid is OFFLINE");
        }
    }
}