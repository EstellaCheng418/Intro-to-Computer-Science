package cheng.DROIDS;

import cheng.ARMS.LeftArm;
import cheng.ARMS.RightArm;
import cheng.BODY.Chasis;
import cheng.BODY.SensorDome;
import cheng.INTERFACES.Droidable;

public abstract class AstromechDroid implements Droidable {

    private String serialNumber;
    private double height;
    private double weight;

    private SensorDome dome;
    private Chasis chasis;
    private LeftArm leftArm;
    private RightArm rightArm;

    public AstromechDroid(String serialNumber) {
        this.serialNumber = serialNumber;
    }

    public abstract void checkStatus();

    // Getters
    public String getSerialNumber() {
        return serialNumber;
    }

    public double getHeight() {
        return height;
    }

    public double getWeight() {
        return weight;
    }

    public SensorDome getDome() {
        return dome;
    }

    public Chasis getChasis() {
        return chasis;
    }

    public LeftArm getLeftArm() {
        return leftArm;
    }

    public RightArm getRightArm() {
        return rightArm;
    }

    // Setters

    public void setHeight(double height) {
        this.height = height;
    }

    public void setWeight(double weight) {
        this.weight = weight;
    }

    public void setDome(SensorDome dome) {
        this.dome = dome;
    }

    public void setChasis(Chasis chasis) {
        this.chasis = chasis;
    }

    public void setLeftArm(LeftArm leftArm) {
        this.leftArm = leftArm;
    }

    public void setRightArm(RightArm rightArm) {
        this.rightArm = rightArm;
    }
}