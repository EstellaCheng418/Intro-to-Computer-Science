package cheng.ENUMS;

public enum Side {
    LEFT, RIGHT
}