package cheng.ENUMS;

public enum Status {
    ONLINE, OFFLINE
}