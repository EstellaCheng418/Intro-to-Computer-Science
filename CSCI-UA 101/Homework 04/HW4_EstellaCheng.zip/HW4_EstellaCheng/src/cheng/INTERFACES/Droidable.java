package cheng.INTERFACES;

import java.util.Random;

public interface Droidable {

    public abstract void displayDroid();

    public static String generateR3SerialNumber() {
        Random rand = new Random();

        String serial = "R3-";
        for (int i = 0; i < 3; i++) {
            serial += (rand.nextInt(9) + 1);
        }
        return serial;
    }

    public static String generateR4SerialNumber() {
        Random rand = new Random();

        String serial = "R4-";
        for (int i = 0; i < 4; i++) {
            serial += (rand.nextInt(9) + 1);
        }
        return serial;
    }
}