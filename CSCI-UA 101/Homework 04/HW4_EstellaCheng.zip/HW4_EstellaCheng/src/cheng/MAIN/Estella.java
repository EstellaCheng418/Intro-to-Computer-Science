package cheng.MAIN;

import java.io.IOException;

import cheng.FACTORY.R3Factory;
import cheng.FACTORY.R4Factory;

public class Estella {

    public static void main(String[] args) throws IOException {

        R3Factory R3 = new R3Factory("GR3");
        R3.buildDroids(2);
        R3.displayDroids();
        System.out.println("***********");
        System.out.println();

        R4Factory R4 = new R4Factory("GR4");
        R4.buildDroids(2);
        R4.displayDroids();
    }
}