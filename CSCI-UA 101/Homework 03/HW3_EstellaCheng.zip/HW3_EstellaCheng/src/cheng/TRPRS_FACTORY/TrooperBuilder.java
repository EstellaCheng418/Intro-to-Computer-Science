package cheng.TRPRS_FACTORY;

import java.util.Random;

import cheng.TRPRS.AssaultTrooper;
import cheng.TRPRS.ScoutTrooper;
import cheng.TRPRS.Stormtrooper;

public class TrooperBuilder {
	
    public static String generateID(String trprType) {
        Random rand = new Random();
        int d = rand.nextInt(10);
        int n = rand.nextInt(100) + 10;

        if (trprType.equals("Scout")) {
            return "SCT-" + d + "#" + n;
        }
        return "ASLT-" + d + "*" + n;
    }

    public static String generateRank(String trprType) {
        Random rand = new Random();

        if (trprType.equals("Scout")) {
            String[] ranks = {"Private", "Lance Corporal", "Corporal", "Sergeant", "Staff Sergeant"};
            return ranks[rand.nextInt(ranks.length)];
        }

        String[] ranks = {"Private", "Lance Corporal", "Corporal", "Sergeant"};
        return ranks[rand.nextInt(ranks.length)];
    }

    public static double[] generateHeightWeight(String trprType) {
        Random rand = new Random();
        double[] hw = new double[2];

        if (trprType.equals("Scout")) {
            int h = rand.nextInt(4) + 70;   // 70-73
            hw[0] = h;
            hw[1] = h * 2.8;
        }
        else {
            int h = rand.nextInt(4) + 72;   // 72-75
            hw[0] = h;
            hw[1] = h * 3.1;
        }

        return hw;
    }

    public static int generateAge(String trprRank) {
        Random rand = new Random();

        if (trprRank.equals("Private")) {
            return rand.nextInt(2) + 18;    // 18-19
        }
        if (trprRank.equals("Lance Corporal")) {
            return rand.nextInt(3) + 19;    // 19-21
        }
        if (trprRank.equals("Corporal")) {
            return rand.nextInt(6) + 20;    // 20-25
        }
        if (trprRank.equals("Sergeant")) {
            return rand.nextInt(7) + 26;    // 26-32
        }
        return rand.nextInt(10) + 30;       // 30-39 Staff Sergeant
    }

    public static Stormtrooper[] buildTroopers(int scout, int assault) {
        Stormtrooper[] trprs = new Stormtrooper[scout + assault];
        int index = 0;

        for (int i = 0; i < scout; i++) {
            String id = generateID("Scout");
            String rank = generateRank("Scout");
            double[] hw = generateHeightWeight("Scout");
            int age = generateAge(rank);

            trprs[index] = new ScoutTrooper(id, rank, (int) hw[0], hw[1], age);
            index++;
        }

        for (int i = 0; i < assault; i++) {
            String id = generateID("Assault");
            String rank = generateRank("Assault");
            double[] hw = generateHeightWeight("Assault");
            int age = generateAge(rank);

            trprs[index] = new AssaultTrooper(id, rank, (int) hw[0], hw[1], age);
            index++;
        }

        return trprs;
    }

    public static void displayAllTroopers(Stormtrooper[] trprs) {
        for (int i = 0; i < trprs.length; i++) {
            if (trprs[i] instanceof ScoutTrooper) {
                ((ScoutTrooper) trprs[i]).displayScoutTrooper();
            }
            else if (trprs[i] instanceof AssaultTrooper) {
                ((AssaultTrooper) trprs[i]).displayAssaultTrooper();
            }
            System.out.println();
        }
    }
}