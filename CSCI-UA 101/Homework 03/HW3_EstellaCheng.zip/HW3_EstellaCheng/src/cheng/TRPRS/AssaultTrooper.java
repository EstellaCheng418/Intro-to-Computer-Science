package cheng.TRPRS;

public class AssaultTrooper extends Stormtrooper {

    private String assaultCode;
    public static int assaultTroopers = 121;

    public AssaultTrooper() {
        super();
        assaultTroopers++;
    }

    public AssaultTrooper(String trprID) {
        super(trprID, "Assault", "Private", 72, 223.2, 18);
        this.assaultCode = trprID + "_" + assaultTroopers;
        assaultTroopers++;
    }

    public AssaultTrooper(String trprID, String trprRank, int trprHeight,
                          double trprWeight, int trprAge) {
        super(trprID, "Assault", trprRank, trprHeight, trprWeight, trprAge);
        this.assaultCode = trprID + "_" + assaultTroopers;
        assaultTroopers++;
    }

    public String getAssaultCode() {
        return assaultCode;
    }

    public void displayAssaultTrooper() {
        System.out.println("***ASSAULT TROOPER***");
        System.out.println(this.toString());
        System.out.println("        Assault Code: " + assaultCode);
    }
}