package cheng.TRPRS;

public class ScoutTrooper extends Stormtrooper {

    private String scoutCode;
    public static int scoutTroopers = 56;
    
    public ScoutTrooper() {
        super();
        scoutTroopers++;
    }

    public ScoutTrooper(String trprID) {
        super(trprID, "Scout", "Private", 70, 196.0, 18);
        this.scoutCode = trprID + "_" + scoutTroopers;
        scoutTroopers++;
    }

    public ScoutTrooper(String trprID, String trprRank, int trprHeight,
                        double trprWeight, int trprAge) {
        super(trprID, "Scout", trprRank, trprHeight, trprWeight, trprAge);
        this.scoutCode = trprID + "_" + scoutTroopers;
        scoutTroopers++;
    }

    public String getScoutCode() {
        return scoutCode;
    }

    public void displayScoutTrooper() {
        System.out.println("###SCOUT TROOPER###");
        System.out.println(this.toString());
        System.out.println("        Scout Code: " + scoutCode);
    }
}