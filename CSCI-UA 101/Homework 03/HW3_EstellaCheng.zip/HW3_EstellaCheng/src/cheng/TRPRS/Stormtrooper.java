package cheng.TRPRS;

public class Stormtrooper {
	// Attribute
    private String trprID;
    private String trprType;
    private String trprRank;
    private int trprHeight;
    private double trprWeight;
    private int trprAge;
    
    // Static variables 
    public static String nationality = "Galactic Empire";
    public static int stormtrooperCount = 0;
    
    // Constructors 
    public Stormtrooper() {
        stormtrooperCount++;
    }

    public Stormtrooper(String trprID) {
        this.trprID = trprID;
        this.trprType = "";
        this.trprRank = "";
        this.trprHeight = 0;
        this.trprWeight = 0.0;
        this.trprAge = 0;
        stormtrooperCount++;
    }

    public Stormtrooper(String trprID, String trprType, String trprRank,
                        int trprHeight, double trprWeight, int trprAge) {
        this.trprID = trprID;
        this.trprType = trprType;
        this.trprRank = trprRank;
        this.trprHeight = trprHeight;
        this.trprWeight = trprWeight;
        this.trprAge = trprAge;
        stormtrooperCount++;
    }
    
    // Getters
    public String getTrprID() {
        return trprID;
    }

    public String getTrprType() {
        return trprType;
    }

    public String getTrprRank() {
        return trprRank;
    }

    public int getTrprHeight() {
        return trprHeight;
    }

    public double getTrprWeight() {
        return trprWeight;
    }

    public int getTrprAge() {
        return trprAge;
    }

    @Override
    public String toString() {
        String out = "";
        out += "        Trpr ID: " + trprID + "\n";
        out += "        Trpr Type: " + trprType + "\n";
        out += "        Trpr Rank: " + trprRank + "\n";
        out += "        Trpr Height: " + trprHeight + "\n";
        out += String.format("        Trpr Weight: %.2f%n", trprWeight);
        out += "        Trpr Age: " + trprAge;
        return out;
    }

    public void displayTrooper() {
        System.out.println(this.toString());
    }
}