package cheng.MAIN;

import cheng.TRPRS.AssaultTrooper;
import cheng.TRPRS.ScoutTrooper;
import cheng.TRPRS_FACTORY.TrooperBuilder;

public class Estella {

    public static void main(String[] args) {

        System.out.println("___Manual Building Process___\n");
        
        // Assault Trooper
        AssaultTrooper A1 = new AssaultTrooper("ASLT-0*0","Private",72,223.2,18);
        A1.displayAssaultTrooper();
        System.out.println();
        
        // Scout Trooper
        ScoutTrooper S1 = new ScoutTrooper("SCT-#0#0", "Private",70,196,18);
        S1.displayScoutTrooper();
        System.out.println("\n___Automatic Building Process___\n");
        
        // Build and Display Random Trooper Array
        TrooperBuilder.displayAllTroopers(TrooperBuilder.buildTroopers(2, 2));
    }
}