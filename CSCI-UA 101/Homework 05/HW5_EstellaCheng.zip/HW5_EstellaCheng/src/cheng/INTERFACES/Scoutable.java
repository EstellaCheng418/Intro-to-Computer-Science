package cheng.INTERFACES;

public interface Scoutable {
    String[] ltrs = {"A", "B", "C", "D", "E", "F"};
    String fp = "src/cheng/TRPR_DATA/sct_troopers";
}