package cheng.INTERFACES;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Random;

import cheng.ENUMS.Rank;
import cheng.TROOPERS.AssaultTrooper;
import cheng.TROOPERS.ScoutTrooper;
import cheng.TROOPERS.Stormtrooper;

public interface Trooperable {

    static Stormtrooper generateTrooper(String trprType) {
        Random rand = new Random();

        String id = "";
        String rank = Rank.values()[rand.nextInt(Rank.values().length)].name();
        int age = rand.nextInt(5) + 24;      // 24 - 28
        double weight = rand.nextInt(16) + 200; // 200 - 215

        if (trprType.equalsIgnoreCase("Scout")) {
            String first = Scoutable.ltrs[rand.nextInt(Scoutable.ltrs.length)];
            String second = Scoutable.ltrs[rand.nextInt(Scoutable.ltrs.length)];
            int digits = rand.nextInt(9000) + 1000;
            id = first + second + "-" + digits;

            ScoutTrooper scout = new ScoutTrooper(id, rank, age);
            scout.setTrooperWeight(weight);
            return scout;
        }

        if (trprType.equalsIgnoreCase("Assault")) {
            String first = Assaultable.ltrs[rand.nextInt(Assaultable.ltrs.length)];
            String second = Assaultable.ltrs[rand.nextInt(Assaultable.ltrs.length)];
            int digits = rand.nextInt(9000) + 1000;
            id = first + second + "-" + digits;

            AssaultTrooper assault = new AssaultTrooper(id, rank, age);
            assault.setTrooperWeight(weight);
            return assault;
        }

        return null;
    }

    static ArrayList<Stormtrooper> buildTroopers(int scouts, int assaults) {
        ArrayList<Stormtrooper> trprs = new ArrayList<Stormtrooper>();

        for (int i = 0; i < scouts; i++) {
            trprs.add(generateTrooper("Scout"));
        }

        for (int i = 0; i < assaults; i++) {
            trprs.add(generateTrooper("Assault"));
        }

        return trprs;
    }

    static void storeTroopers(ArrayList<Stormtrooper> trprs) throws IOException {
        ArrayList<ScoutTrooper> scts = new ArrayList<ScoutTrooper>();
        ArrayList<AssaultTrooper> aslts = new ArrayList<AssaultTrooper>();

        for (Stormtrooper s : trprs) {
            if (s instanceof ScoutTrooper) {
                scts.add((ScoutTrooper) s);
            }
            if (s instanceof AssaultTrooper) {
                aslts.add((AssaultTrooper) s);
            }
        }
        
        FileOutputStream S = new FileOutputStream(Scoutable.fp);
        ObjectOutputStream scoutOut = new ObjectOutputStream(S);
        scoutOut.writeObject(scts);
        scoutOut.close();

        FileOutputStream A = new FileOutputStream(Assaultable.fp);
        ObjectOutputStream assaultOut = new ObjectOutputStream(A);
        assaultOut.writeObject(aslts);
        assaultOut.close();
    }

    static ArrayList<Stormtrooper> retrieveTroopers() throws IOException, ClassNotFoundException {
        ArrayList<Stormtrooper> trp = new ArrayList<Stormtrooper>();
        
        FileInputStream S = new FileInputStream(Scoutable.fp);
        ObjectInputStream scoutIn = new ObjectInputStream(S);
        ArrayList<ScoutTrooper> scts = (ArrayList<ScoutTrooper>) scoutIn.readObject();
        scoutIn.close();
        System.out.println("Scout Troopers Deserialized");

        FileInputStream A = new FileInputStream(Assaultable.fp);
        ObjectInputStream assaultIn = new ObjectInputStream(A);        
        ArrayList<AssaultTrooper> aslts = (ArrayList<AssaultTrooper>) assaultIn.readObject();
        assaultIn.close();
        System.out.println("Assault Troopers Deserialized");

        for (ScoutTrooper s : scts) {
            trp.add(s);
        }

        for (AssaultTrooper a : aslts) {
            trp.add(a);
        }

        return trp;
    }
}