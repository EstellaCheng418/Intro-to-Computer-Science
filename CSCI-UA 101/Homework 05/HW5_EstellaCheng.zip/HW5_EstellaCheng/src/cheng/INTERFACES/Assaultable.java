package cheng.INTERFACES;

public interface Assaultable {
    String[] ltrs = {"G", "H", "I", "J", "K", "L"};
    String fp = "src/cheng/TRPR_DATA/aslt_troopers";
}