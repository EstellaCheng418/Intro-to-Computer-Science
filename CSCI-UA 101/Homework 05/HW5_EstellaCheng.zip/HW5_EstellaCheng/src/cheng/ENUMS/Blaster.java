package cheng.ENUMS;

public enum Blaster {
    Light("Lt", 150),
    Heavy("Hvy", 50);

    private String type;
    private int rounds;

    private Blaster(String type, int rounds) {
        this.type = type;
        this.rounds = rounds;
    }

    public String getType() {
        return type;
    }

    public int getRounds() {
        return rounds;
    }
}