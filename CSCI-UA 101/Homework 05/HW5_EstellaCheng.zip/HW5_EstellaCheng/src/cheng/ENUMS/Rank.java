package cheng.ENUMS;

public enum Rank {
    SGT, CPL, PVT
}