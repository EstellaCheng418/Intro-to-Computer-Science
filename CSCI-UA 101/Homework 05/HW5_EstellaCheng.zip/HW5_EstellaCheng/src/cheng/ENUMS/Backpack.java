package cheng.ENUMS;

public enum Backpack {
    Assault("Aslt", 50),
    Heavy("Hvy", 100);

    private String type;
    private int capacity;

    private Backpack(String type, int capacity) {
        this.type = type;
        this.capacity = capacity;
    }

    public String getType() {
        return type;
    }

    public int getCapacity() {
        return capacity;
    }
}