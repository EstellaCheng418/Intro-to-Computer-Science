package cheng.TROOPERS;

import cheng.ENUMS.Backpack;
import cheng.ENUMS.Blaster;

public class ScoutTrooper extends Stormtrooper {

    private String trooperType = "Scout";

    public ScoutTrooper(String trooperID, String trooperRank, int trooperAge) {
        super(trooperID, trooperRank, trooperAge);
        setPack(Backpack.Assault);
        setWpn(Blaster.Light);
        setTrooperHeight(76.0);
    }

    public String getTrooperType() {
        return trooperType;
    }

    public void displayScout() {
        System.out.println("Scout Trooper");
        System.out.println("Trooper ID: " + getTrooperID());
        System.out.printf("Rank: %-9s Height: %.1f    Weight: %.1f   Age: %d%n",
                getTrooperRank(), getTrooperHeight(), getTrooperWeight(), getTrooperAge());
        System.out.printf("Pack: %-8s Pack Capacity: %d    	Weapon: %-5s  Wpn Rounds: %d%n",
                getPack().name(), getPack().getCapacity(), getWpn().name(), getWpn().getRounds());
    }
}