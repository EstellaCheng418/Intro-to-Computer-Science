package cheng.TROOPERS;

import cheng.ENUMS.Backpack;
import cheng.ENUMS.Blaster;

public class AssaultTrooper extends Stormtrooper {

    private String trooperType = "Assault";

    public AssaultTrooper(String trooperID, String trooperRank, int trooperAge) {
        super(trooperID, trooperRank, trooperAge);
        setPack(Backpack.Heavy);
        setWpn(Blaster.Heavy);
        setTrooperHeight(78.0);
    }

    public String getTrooperType() {
        return trooperType;
    }

    public void displayAssault() {
        System.out.println("Assault Trooper");
        System.out.println("Trooper ID: " + getTrooperID());
        System.out.printf("Rank: %-9s Height: %.1f    Weight: %.1f   Age: %d%n",
                getTrooperRank(), getTrooperHeight(), getTrooperWeight(), getTrooperAge());
        System.out.printf("Pack: %-6s Pack Capacity: %d Weapon: %-5s  Wpn Rounds: %d%n",
                getPack().name(), getPack().getCapacity(), getWpn().name(), getWpn().getRounds());
    }
}