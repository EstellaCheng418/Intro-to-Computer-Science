package cheng.TROOPERS;

import java.io.Serializable;

import cheng.ENUMS.Backpack;
import cheng.ENUMS.Blaster;

public abstract class Stormtrooper implements Serializable {

    private static final long serialVersionUID = 1L;

    private String trooperID;
    private String trooperRank;
    private double trooperHeight;
    private double trooperWeight;
    private Backpack pack;
    private Blaster wpn;
    private int trooperAge;

    public Stormtrooper(String trooperID, String trooperRank, int trooperAge) {
        this.trooperID = trooperID;
        this.trooperRank = trooperRank;
        this.trooperAge = trooperAge;
    }

    public String getTrooperID() {
        return trooperID;
    }

    public void setTrooperID(String trooperID) {
        this.trooperID = trooperID;
    }

    public String getTrooperRank() {
        return trooperRank;
    }

    public void setTrooperRank(String trooperRank) {
        this.trooperRank = trooperRank;
    }

    public double getTrooperHeight() {
        return trooperHeight;
    }

    public void setTrooperHeight(double trooperHeight) {
        this.trooperHeight = trooperHeight;
    }

    public double getTrooperWeight() {
        return trooperWeight;
    }

    public void setTrooperWeight(double trooperWeight) {
        this.trooperWeight = trooperWeight;
    }

    public Backpack getPack() {
        return pack;
    }

    public void setPack(Backpack pack) {
        this.pack = pack;
    }

    public Blaster getWpn() {
        return wpn;
    }

    public void setWpn(Blaster wpn) {
        this.wpn = wpn;
    }

    public int getTrooperAge() {
        return trooperAge;
    }

    public void setTrooperAge(int trooperAge) {
        this.trooperAge = trooperAge;
    }

    @Override
    public String toString() {
        return "Trooper ID: " + trooperID
                + "\nRank: " + trooperRank
                + "\nHeight: " + trooperHeight
                + "\nWeight: " + trooperWeight
                + "\nAge: " + trooperAge
                + "\nPack: " + pack
                + "\nWeapon: " + wpn;
    }
}