package cheng.MAIN;

import java.io.IOException;
import java.util.ArrayList;

import cheng.INTERFACES.Trooperable;
import cheng.TROOPERS.AssaultTrooper;
import cheng.TROOPERS.ScoutTrooper;
import cheng.TROOPERS.Stormtrooper;

public class Estella {

    public static void main(String[] args) throws IOException, ClassNotFoundException {

        Trooperable.storeTroopers(Trooperable.buildTroopers(2, 2));
        ArrayList<Stormtrooper> trp = Trooperable.retrieveTroopers();
        System.out.println();

        for (Stormtrooper s : trp) {
            if (s.getClass().toString().contains("Scout")) {
                ((ScoutTrooper) s).displayScout();
            }
            if (s.getClass().toString().contains("Assault")) {
                ((AssaultTrooper) s).displayAssault();
            }

            System.out.println();
        }
    }
}