package cheng.ENUMS;

public enum Sector {
    Alpha, Beta, Gamma, Delta
}