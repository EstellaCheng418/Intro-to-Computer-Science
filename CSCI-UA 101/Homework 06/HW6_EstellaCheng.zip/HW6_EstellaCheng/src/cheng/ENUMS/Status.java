package cheng.ENUMS;

public enum Status {
    Intact, Corrupted
}