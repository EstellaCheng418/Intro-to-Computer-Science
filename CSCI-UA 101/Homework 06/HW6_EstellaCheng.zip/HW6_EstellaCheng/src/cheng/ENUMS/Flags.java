package cheng.ENUMS;

public enum Flags {
    IDCODE, VALUE, STATUS
}