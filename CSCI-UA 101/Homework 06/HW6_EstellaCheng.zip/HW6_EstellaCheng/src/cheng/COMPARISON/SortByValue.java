package cheng.COMPARISON;

import java.util.Comparator;

import cheng.MEMORY.Memory;

public class SortByValue implements Comparator<Memory> {

    @Override
    public int compare(Memory m1, Memory m2) {
        String s1 = (m1 == null || m1.getValue() == null) ? "" : m1.getValue();
        String s2 = (m2 == null || m2.getValue() == null) ? "" : m2.getValue();
        return s1.compareTo(s2);
    }
}