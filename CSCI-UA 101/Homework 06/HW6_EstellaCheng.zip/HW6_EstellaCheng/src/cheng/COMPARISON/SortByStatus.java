package cheng.COMPARISON;

import java.util.Comparator;

import cheng.MEMORY.Memory;

public class SortByStatus implements Comparator<Memory> {

    @Override
    public int compare(Memory m1, Memory m2) {
        String s1 = m1 == null || m1.getStatus() == null ? "" : m1.getStatus().toString();
        String s2 = m2 == null || m2.getStatus() == null ? "" : m2.getStatus().toString();
        return s1.compareTo(s2); // Corrupted come before Intact
    }
}