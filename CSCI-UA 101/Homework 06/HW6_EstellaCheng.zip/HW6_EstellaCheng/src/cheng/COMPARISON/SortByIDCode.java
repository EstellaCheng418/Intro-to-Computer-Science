package cheng.COMPARISON;

import java.util.Comparator;

import cheng.MEMORY.Memory;

public class SortByIDCode implements Comparator<Memory> {

    @Override
    public int compare(Memory m1, Memory m2) {
        String s1 = (m1 == null || m1.getIdCode() == null) ? "" : m1.getIdCode();
        String s2 = (m2 == null || m2.getIdCode() == null) ? "" : m2.getIdCode();
        return s1.compareTo(s2);
    }
}