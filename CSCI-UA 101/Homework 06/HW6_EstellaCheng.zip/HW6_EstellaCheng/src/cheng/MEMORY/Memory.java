package cheng.MEMORY;

import java.io.Serializable;
import java.util.TreeMap;

import cheng.ENUMS.Status;

public class Memory implements Serializable {
    private static final long serialVersionUID = 1L;

    private TreeMap<String, String> memoryData;

    public Memory() {
    		// initializes no state
    }

    public Memory(String idCode, String value, Status status) {
        memoryData = new TreeMap<String, String>();
        memoryData.put("idCode", idCode);
        memoryData.put("value", value);
        memoryData.put("status", status.name());
    }
    
    // Getters and Setters
    public String getIdCode() {
        return memoryData.get("idCode");
    }

    public void setIdCode(String idCode) {
        memoryData.put("idCode", idCode);
    }

    public String getValue() {
        return memoryData.get("value");
    }

    public void setValue(String value) {
        memoryData.put("value", value);
    }

    public Status getStatus() {
        String s = memoryData.get("status");
        if (s == null) {
            return null;
        }
        return Status.valueOf(s);
    }

    public void setStatus(Status status) {
        memoryData.put("status", status == null ? null : status.name());
    }
    
    public TreeMap<String, String> getMemoryData() {
        return memoryData;
    }

    public void setMemoryData(TreeMap<String, String> memoryData) {
        this.memoryData = memoryData;
    }
    
    // Null memory object if idCode, value, and status are null
    public boolean isNullMemory() {
        return getIdCode() == null && getValue() == null && getStatus() == null;
    }

    @Override
    public String toString() {
        return String.format("Memory: %-12s Value: %-10s Status: %s",
                getIdCode(), getValue(), getStatus());
    }

    public void display() {
        System.out.println(toString());
    }

    public boolean fix() {
        if (getStatus() == Status.Corrupted) {
            setStatus(Status.Intact);
            return true;
        }
        return false;
    }

    public boolean erase() {
        setIdCode(null);
        setValue(null);
        setStatus(null);
        return true;
    }

}