package cheng.MEMORY;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;

import cheng.ASSEMBLER.MemoryBuilder;
import cheng.COMPARISON.SortByIDCode;
import cheng.COMPARISON.SortByStatus;
import cheng.COMPARISON.SortByValue;
import cheng.ENUMS.Flags;
import cheng.ENUMS.Sector;
import cheng.ENUMS.Status;

public class MemoryBank implements Serializable {
    private static final long serialVersionUID = 1L;

    private String bankID;
    private ArrayList<Memory> memoryBank;

    public MemoryBank() {
        this.bankID = null;
        this.memoryBank = new ArrayList<Memory>();
    }

    public MemoryBank(String bankID, MemoryBuilder M) {
        this.bankID = bankID;
        this.memoryBank = new ArrayList<Memory>();

        if (M != null) {
            while (!M.getMemoryQueue().isEmpty() && memoryBank.size() < 8) {
                memoryBank.add(M.getMemoryQueue().poll()); // move Memory objects from the builder (queue) into the bank (ArrayList)
            }
        }
    }

    // Getters and Setters
    public String getBankID() {
        return bankID;
    }

    public void setBankID(String bankID) {
        this.bankID = bankID;
    }

    public ArrayList<Memory> getMemoryBank() {
        return memoryBank;
    }
    
    // Methods
    public void clear() {
        memoryBank.clear();
    }
    
    // prints the bank ID and all Memory objects inside the bank
    public void display() {
        System.out.println("Memory Bank ID: " + bankID);
        Iterator<Memory> it = memoryBank.iterator();

        while (it.hasNext()) {
            it.next().display();
        }
    }
    
    // removes all Memory objects from the bank
    public boolean flush() {
        memoryBank.clear();
        System.out.println("Memory Bank is " + memoryBank.size() + "/8 Full");
        return true;
    }
    
    // copies all Memory objects from the bank into an array, return it
    // "Prints to the Console a String representation of the returned array showing the Memory object idCodes" 
    // -> For Task 3, an additional line get printed when compared to Prof's expected output
    public Memory[] dump() {
        Memory[] arr = new Memory[memoryBank.size()];
        StringBuilder sb = new StringBuilder("[");
        for (int i = 0; i < memoryBank.size(); i++) {
            arr[i] = memoryBank.get(i);
            if (i > 0) sb.append(", ");
            sb.append(arr[i].getIdCode());
        }
        sb.append("]");
        System.out.println(sb.toString());
        return arr;
    }
    
    // creates a new MemoryBank with the same data by copying every Memory object + print
    public MemoryBank replicate() {
        MemoryBank copy = new MemoryBank();
        copy.setBankID(this.bankID);

        for (Memory m : this.memoryBank) {
            copy.getMemoryBank().add(new Memory(m.getIdCode(), m.getValue(), m.getStatus()));
        }

        copy.display();
        return copy;
    }
    
    // sorts MemoryBuilder based on criteria f
    public boolean reorder(Flags f) {
        if (f == Flags.IDCODE) {
            Collections.sort(memoryBank, new SortByIDCode());
        } else if (f == Flags.VALUE) {
            Collections.sort(memoryBank, new SortByValue());
        } else if (f == Flags.STATUS) {
            Collections.sort(memoryBank, new SortByStatus());
        }
        return true;
    }
    
    // e.g. Sector :Alpha
    //			  Mloc_0: 10110_22      Mloc_1: 111_7
    public void displaySector(Sector s) {
        System.out.println("Sector :" + s);

        int start = 0;
        if (s == Sector.Alpha) {
            start = 0;
        } else if (s == Sector.Beta) {
            start = 2;
        } else if (s == Sector.Gamma) {
            start = 4;
        } else if (s == Sector.Delta) {
            start = 6;
        }

        Memory[] sec = getSector(s);

        for (int i = 0; i < sec.length; i++) {
            System.out.print("      Mloc_" + (start + i) + ": " + sec[i].getValue() + "   ");
        }
        System.out.println();
    }
    
    // e.g. Memory[abc_1234] Found At Mloc_3
    public boolean findMemory(String idCode) {
        for (int i = 0; i < memoryBank.size(); i++) {
            Memory m = memoryBank.get(i);
            if (m != null && m.getIdCode() != null && m.getIdCode().equals(idCode)) {
                System.out.println("Memory[" + idCode + "] Found At Mloc_" + i);
                return true;
            }
        }

        System.out.println("Memory Not Found");
        return false;
    }
    
    // converts an address into an index, finds that Memory, prints it, and returns 
    public Memory returnMemory(String addr) {
        int index;
        try {
            index = Integer.parseInt(addr.substring(addr.indexOf('_') + 1));
        } catch (Exception e) {
            return null;
        }

        if (index < 0 || index >= memoryBank.size()) {
            return null;
        }

        Memory m = memoryBank.get(index);
        m.display();
        return m;
    }
    
    // swaps two Memory objects in the bank using their addresses
    public boolean swapMemory(String addr1, String addr2) {
        int i;
        int j;

        try {
            i = Integer.parseInt(addr1.substring(addr1.indexOf('_') + 1));
            j = Integer.parseInt(addr2.substring(addr2.indexOf('_') + 1));
        } catch (Exception e) {
            return false;
        }

        if (i < 0 || j < 0 || i >= memoryBank.size() || j >= memoryBank.size()) {
            return false;
        }

        Memory temp = memoryBank.get(i);
        memoryBank.set(i, memoryBank.get(j));
        memoryBank.set(j, temp);
        return true;
    }
    
 // returns 2 Memory objects that belong to a specific sector
    public Memory[] getSector(Sector s) {
        int start = 0;
        if (s == Sector.Alpha) {
            start = 0;
        } else if (s == Sector.Beta) {
            start = 2;
        } else if (s == Sector.Gamma) {
            start = 4;
        } else if (s == Sector.Delta) {
            start = 6;
        }

        Memory[] arr = new Memory[2];
        if (start + 1 < memoryBank.size()) {
            arr[0] = memoryBank.get(start);
            arr[1] = memoryBank.get(start + 1);
        } else if (start < memoryBank.size()) {
            arr[0] = memoryBank.get(start);
            arr[1] = null;
        }

        return arr;
    }

    // add Memory object m if bank not full
    public boolean insertMemory(Memory m) {
        if (memoryBank.size() < 8) {
            memoryBank.add(m);
            return true;
        }

        System.out.println("Memory Bank is Full Insert Fails");
        return false;
    }
    
    // adds multiple Memory objects (a cache) into the bank until the bank is full
    public boolean insertCache(Memory[] m) {
        if (m == null || m.length == 0) {
            System.out.println("Cache is Empty...No Memory Inserted");
            return false;
        }

        for (Memory each : m) {
            if (memoryBank.size() < 8) {
                memoryBank.add(each);
            }
        }

        System.out.println("Cache Inserted");
        return true;
    }
    
    // remove memory object from bank that corresponds to m, return true
    public boolean removeMemory(Memory[] m) {
        if (m == null) {
            return false;
        }

        for (int i = 0; i < m.length; i++) {
            Memory target = m[i];

            for (int j = 0; j < memoryBank.size(); j++) {
                Memory current = memoryBank.get(j);

                if (current.getIdCode().equals(target.getIdCode()) &&
                    current.getValue().equals(target.getValue()) &&
                    current.getStatus() == target.getStatus()) {

                    memoryBank.remove(j);
                    break; // stop after removing one match
                }
            }
        }

        return true;
    }
    
    // changes the value of a Memory at a specific address and prints the change
    public boolean updateMemory(String addr, String value) {
        int index;
        try {
            index = Integer.parseInt(addr.substring(addr.indexOf('_') + 1));
        } catch (Exception e) {
            return false;
        }

        if (index < 0 || index >= memoryBank.size()) {
            return false;
        }

        Memory m = memoryBank.get(index);
        String oldValue = m.getValue();
        m.setValue(value);

        System.out.println("Memory Value was: " + oldValue + " Memory Updated To: " + value);
        return true;
    }
    
    // e.g. Corrupted Memory: 1 Intact Memory: 1
    public boolean validateMemory(String[] addr) {
        int corrupted = 0;
        int intact = 0;

        for (String a : addr) {
            int index;
            try {
                index = Integer.parseInt(a.substring(a.indexOf('_') + 1));
            } catch (Exception e) {
                continue;
            }

            if (index >= 0 && index < memoryBank.size()) {
                if (memoryBank.get(index).getStatus() == Status.Corrupted) {
                    corrupted++;
                } else if (memoryBank.get(index).getStatus() == Status.Intact) {
                    intact++;
                }
            }
        }

        System.out.println("Corrupted Memory: " + corrupted + " Intact Memory: " + intact);
        return true;
    }

    // serialize MemoryBank object into a file
    public void persistMemory(String filename) throws IOException {
    	String folderPath = "src" + File.separator + "cheng" + File.separator + "PERSIST";
        File folder = new File(folderPath);
        if (!folder.exists()) {
            folder.mkdirs();
        }

        String fullPath = folderPath + File.separator + filename;

        ObjectOutputStream oos = new ObjectOutputStream(
                new BufferedOutputStream(new FileOutputStream(fullPath)));
        oos.writeObject(this);
        oos.close();

        System.out.println("Memory Bank has been stored at " + fullPath);
    }
    
    // read a MemoryBank from a file and returns it
    public MemoryBank constituteMemory(String filename) throws IOException, ClassNotFoundException {
    	String fullPath = "src" + File.separator + "cheng" + File.separator + "PERSIST" + File.separator + filename;

        ObjectInputStream ois = new ObjectInputStream(
                new BufferedInputStream(new FileInputStream(fullPath)));
        MemoryBank mb = (MemoryBank) ois.readObject();
        ois.close();

        mb.display();
        return mb;
    }
    
    // Compare two MemoryBanks using iterators, print, count differences
    public boolean compareBanks(MemoryBank mb) {
        Iterator<Memory> it1 = this.memoryBank.iterator();
        Iterator<Memory> it2 = mb.memoryBank.iterator();

        int diffCount = 0;

        while (it1.hasNext() && it2.hasNext()) {
            Memory m1 = it1.next();
            Memory m2 = it2.next();

            if (m1.getIdCode().equals(m2.getIdCode()) &&
                m1.getValue().equals(m2.getValue()) &&
                m1.getStatus() == m2.getStatus()) {

                System.out.println(m1.getIdCode() + " = " + m2.getIdCode());
            } else {
                System.out.println(m1.getIdCode() + " <> " + m2.getIdCode());
                diffCount++;
            }
        }

        if (diffCount == 0) {
            System.out.println("Memory Banks Are Indentical");
        } else {
            System.out.println("Memory Banks Are Not Indentical");
        }

        System.out.println("There are " + diffCount + " Different Memory Object");
        return true;
    }
    
    // fix corrupted memories, print repaired one, output total repaired count
    public boolean repairMemory() {
        Iterator<Memory> it = memoryBank.iterator();
        int repaired = 0;

        while (it.hasNext()) {
            Memory m = it.next();
            if (m != null && m.fix()) {
                m.display();
                repaired++;
            }
        }

        System.out.println(repaired + " Memory Objects have been repaired");
        return true;
    }
    
}