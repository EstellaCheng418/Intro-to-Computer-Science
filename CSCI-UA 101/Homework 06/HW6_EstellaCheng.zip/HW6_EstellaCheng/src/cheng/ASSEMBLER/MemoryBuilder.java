package cheng.ASSEMBLER;

import java.util.Random;
import java.util.concurrent.LinkedBlockingQueue;

import cheng.ENUMS.Status;
import cheng.MEMORY.Memory;

public class MemoryBuilder {

    private String id;
    private LinkedBlockingQueue<Memory> memoryQueue;
    private Random rand;

    public MemoryBuilder(String id) {
        this.id = id;
        this.memoryQueue = new LinkedBlockingQueue<Memory>(8);
        this.rand = new Random();
    }
    
    // Getters
    public String getId() {
        return id;
    }

    public LinkedBlockingQueue<Memory> getMemoryQueue() {
        return memoryQueue;
    }
    
    // Methods
    // e.g. 3 lowercase letters_4 digits
    public String generateIDCode() {
        StringBuilder sb = new StringBuilder();

        for (int i = 0; i < 3; i++) {
            char c = (char) ('a' + rand.nextInt(26));
            sb.append(c);
        }

        sb.append('_');

        for (int i = 0; i < 4; i++) {
            sb.append(rand.nextInt(10));
        }

        return sb.toString();
    }
    
    //(binary version of v)_(original number)
    public String generateValue(int v) {
        return Integer.toBinaryString(v) + "_" + v;
    }
    
    // random Status
    public Status generateStatus() {
        return rand.nextBoolean() ? Status.Intact : Status.Corrupted;
    }
    
    // build 8 random Memory objects and stores them in the queue
    public boolean buildMemory() {
        memoryQueue.clear();

        for (int i = 0; i < 8; i++) {
            String idCode = generateIDCode();
            int n = rand.nextInt(65); // 0 to 64 inclusive
            String value = generateValue(n);
            Status status = generateStatus();

            memoryQueue.offer(new Memory(idCode, value, status)); // Memory object is created and stored
        }

        System.out.println("Memory Build Complete");
        return true;
    }
    
    // adds a Memory only if the queue has space
    public boolean offerMemory(Memory m) {
        if (memoryQueue.size() <= 7) {
            memoryQueue.offer(m);
            System.out.println("Memory Added");
            return true;
        }

        System.out.println("Builder is Full");
        return false;
    }
    
    // removes the first item in the queue + return
    // e.g. Memory Object [Memory: abc_1234 Value: 10110_22 Status: Intact] has been retrieved
    public Memory pollMemory() {
        Memory m = memoryQueue.poll();
        System.out.println("Memory Object [" + m + "] has been retrieved");
        return m;
    }
    
    // remove all Memory objects from the queue
    public boolean clearMemory() {
        memoryQueue.clear();
        System.out.println("Memory Builder has " + memoryQueue.size() + " Memory Objects");
        return true;
    }
}